import express from "express";
import cors from "cors";
import db from "./db.js";

const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json());

app.get("/api/quote", async (req, res) => {
  try {
    const response = await fetch("https://api.quotable.io/random");
    if (!response.ok) throw new Error("Quote API request failed");

    const data = await response.json();
    res.json({
      quote: data.content,
      author: data.author
    });
  } catch (error) {
    res.status(500).json({ error: "Unable to fetch quote." });
  }
});

app.get("/api/favorites", (req, res) => {
  const favorites = db
    .prepare("SELECT * FROM favorites ORDER BY created_at DESC")
    .all();

  res.json(favorites);
});

app.post("/api/favorites", (req, res) => {
  const { quote, author } = req.body;

  if (!quote || !author) {
    return res.status(400).json({ error: "Quote and author are required." });
  }

  const result = db
    .prepare("INSERT INTO favorites (quote, author) VALUES (?, ?)")
    .run(quote, author);

  const favorite = db
    .prepare("SELECT * FROM favorites WHERE id = ?")
    .get(result.lastInsertRowid);

  res.status(201).json(favorite);
});

app.delete("/api/favorites/:id", (req, res) => {
  const result = db
    .prepare("DELETE FROM favorites WHERE id = ?")
    .run(req.params.id);

  if (result.changes === 0) {
    return res.status(404).json({ error: "Favorite not found." });
  }

  res.json({ message: "Favorite deleted." });
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
