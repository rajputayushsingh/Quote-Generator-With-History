# Quote Generator with History

A full-stack quote generator using React, Express, SQLite, and the Quotable public API.

## Features
- Fetch random quotes from a public API
- Save favorite quotes to SQLite
- View favorites history
- Delete favorites
- Copy quotes to clipboard
- Loading and error states

## Run

### 1. Backend
```bash
cd server
npm install
npm start
```

### 2. Frontend
Open a second terminal:
```bash
cd client
npm install
npm run dev
```

Open the Vite URL shown in the terminal.

The backend runs on `http://localhost:5000`.
