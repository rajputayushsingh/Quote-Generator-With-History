import { useEffect, useState } from "react";

const API = "http://localhost:5000/api";

export default function App() {
  const [quote, setQuote] = useState("");
  const [author, setAuthor] = useState("");
  const [favorites, setFavorites] = useState([]);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    getQuote();
    loadFavorites();
  }, []);

  async function getQuote() {
    setLoading(true);
    setError("");
    try {
      const res = await fetch(`${API}/quote`);
      if (!res.ok) throw new Error();
      const data = await res.json();
      setQuote(data.quote);
      setAuthor(data.author);
    } catch {
      setError("Could not fetch a quote. Please try again.");
    } finally {
      setLoading(false);
    }
  }

  async function loadFavorites() {
    try {
      const res = await fetch(`${API}/favorites`);
      const data = await res.json();
      setFavorites(data);
    } catch {
      setError("Could not load favorites.");
    }
  }

  async function favoriteQuote() {
    if (!quote) return;
    try {
      const res = await fetch(`${API}/favorites`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ quote, author })
      });
      if (!res.ok) throw new Error();
      await loadFavorites();
      showMessage("Added to favorites ❤️");
    } catch {
      setError("Could not save favorite.");
    }
  }

  async function deleteFavorite(id) {
    try {
      const res = await fetch(`${API}/favorites/${id}`, { method: "DELETE" });
      if (!res.ok) throw new Error();
      await loadFavorites();
      showMessage("Favorite deleted.");
    } catch {
      setError("Could not delete favorite.");
    }
  }

  async function copyText(text, name = "") {
    try {
      await navigator.clipboard.writeText(`"${text}" — ${name}`.trim());
      showMessage("Copied to clipboard! 📋");
    } catch {
      setError("Clipboard access failed.");
    }
  }

  function showMessage(text) {
    setMessage(text);
    setError("");
    setTimeout(() => setMessage(""), 1800);
  }

  return (
    <main className="container">
      <header>
        <p className="eyebrow">DAILY INSPIRATION</p>
        <h1>✨ Quote Generator</h1>
        <p className="subtitle">Discover a quote, save your favorites, and keep your inspiration history.</p>
      </header>

      <section className="quote-card">
        {loading ? (
          <div className="loading">Loading quote...</div>
        ) : (
          <>
            <div className="quote-mark">“</div>
            <blockquote>{quote || "Your next quote is waiting..."}</blockquote>
            <p className="author">— {author || "Unknown"}</p>

            <div className="actions">
              <button className="primary" onClick={getQuote}>New Quote</button>
              <button onClick={favoriteQuote}>❤️ Favorite</button>
              <button onClick={() => copyText(quote, author)}>📋 Copy</button>
            </div>
          </>
        )}
      </section>

      {message && <div className="toast success">{message}</div>}
      {error && <div className="toast error">{error}</div>}

      <section className="history">
        <div className="history-heading">
          <div>
            <p className="eyebrow">YOUR COLLECTION</p>
            <h2>Favorites History</h2>
          </div>
          <span className="count">{favorites.length}</span>
        </div>

        {favorites.length === 0 ? (
          <div className="empty">No favorites yet. Save a quote to see it here.</div>
        ) : (
          <div className="favorites">
            {favorites.map((item) => (
              <article className="favorite" key={item.id}>
                <p className="favorite-quote">“{item.quote}”</p>
                <p className="favorite-author">— {item.author}</p>
                <div className="favorite-actions">
                  <button onClick={() => copyText(item.quote, item.author)}>📋 Copy</button>
                  <button onClick={() => deleteFavorite(item.id)}>🗑 Delete</button>
                </div>
              </article>
            ))}
          </div>
        )}
      </section>
    </main>
  );
}
